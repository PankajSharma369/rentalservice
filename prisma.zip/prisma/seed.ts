import { PrismaClient } from "@prisma/client";
import fs from "fs";
import csv from "csv-parser";

const prisma = new PrismaClient();

async function main() {
  // Path to the CSV file
  const csvFilePath = "sample_properties.csv";

  // Array to hold the parsed data
  const properties: any[] = [];

  // Read the CSV file
  fs.createReadStream(csvFilePath)
    .pipe(csv())
    .on("data", (row) => {
      // Convert CSV row to Prisma-compatible object
      properties.push({
        name: row.Name,
        type: row.Type,
        description: row.Description,
        address: row.Address,
        price: parseFloat(row.Price),
        bedrooms: parseInt(row.Bedrooms),
        bathrooms: parseInt(row.Bathrooms),
        amenities: row.Amenities.split(",").map((a: string) => a.trim()),
        images: row.Images.split(",").map((i: string) => i.trim()),

        status: row.Status.toLowerCase() === "true",
        dateAdded: new Date(row.DateAdded),
        updatedAt: new Date(row.UpdatedAt),
      });
    })
    .on("end", async () => {
      console.log("CSV file successfully processed.");
      
      // Insert each property into the database
      for (const property of properties) {
        try {
          await prisma.property.create({
            data: property,
          });
          console.log(`Property added: ${property.name}`);
        } catch (error) {
          console.error(`Error adding property ${property.name}:`, error);
        }
      }

      console.log("All properties have been added to the database.");
      await prisma.$disconnect();
    });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
